from django.urls import path
from .views import BusRouteList

urlpatterns = [
    path('', BusRouteList.as_view(), name='bus_route_list'),
]
