from django.contrib import admin
from .models import BusRoute

admin.site.register(BusRoute)
