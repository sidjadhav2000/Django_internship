from rest_framework import generics
from .models import BusRoute
from .serializers import BusRouteSerializer

class BusRouteList(generics.ListCreateAPIView):
    queryset = BusRoute.objects.all()
    serializer_class = BusRouteSerializer
