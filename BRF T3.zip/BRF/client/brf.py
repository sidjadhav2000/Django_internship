from requests import *
from tkinter import *


root = Tk()
root.title("Bus Route Finder Application")
root.geometry("700x500+330+50")
root.configure(bg = "lightblue")
f = ("Arial", 20 , "bold")

def check():
	#wa = "http://127.0.0.1:8000/bus-routes/"
	wa = "http://127.0.0.1:8000/"
	res = get(wa)
	data = res.json()
	route_number = ent_in.get()
	destination = next(("Destination : " +item["destination"] for item in data if item["route_number"] == route_number), "Not Found")
	lab_ans.configure(text =destination)

label_in = Label(root , text  = "Enter Bus Route No : " ,bg="lightblue", font = f )
label_in.pack(pady = 10)
ent_in = Entry(root, font = f )
ent_in.pack(pady = 10)
	
btn = Button(root , text = "Check" ,font = f , command = check)
btn.pack(pady = 10)
lab_ans = Label(root , text = "",bg="lightblue", font = f )
lab_ans.pack(pady = 10) 
root.mainloop()
