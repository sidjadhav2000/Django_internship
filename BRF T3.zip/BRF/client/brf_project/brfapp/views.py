from django.shortcuts import render
import requests

def bus_route(request):
    if request.method == 'POST':
        route_number = request.POST.get('route_number')
        api_url = f"http://127.0.0.1:8000/bus-routes/{route_number}/"
        response = requests.get(api_url)
        data = response.json()
        destination = data.get('destination', 'Not Found')
        return render(request, 'bus_route.html', {'destination': destination})

    return render(request, 'bus_route.html')
