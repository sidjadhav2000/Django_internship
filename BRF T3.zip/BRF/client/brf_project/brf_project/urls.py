from django.urls import path
from brfapp.views import  bus_route

urlpatterns = [
    path('', bus_route, name='bus_route'),
]